"use client"

import { QuizInstructions } from "../components/quiz-instructions"

export default function SyntheticV0PageForDeployment() {
  return <QuizInstructions />
}