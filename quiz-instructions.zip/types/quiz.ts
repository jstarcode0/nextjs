export type QuizCategory = '1st-grade' | '2nd-grade' | 'reet'
export type SubCategory = 'gk' | 'subject' | 'reet-l1-pre' | 'reet-l2-pre' | 'reet-l1-mains' | 'reet-l2-mains'

export interface Question {
  id: number
  question: string
  options: string[]
  correct: number
  isMath?: boolean
}

export interface QuizState {
  currentQuestion: number
  selectedAnswers: { [key: number]: number }
  markedQuestions: number[]
  isSubmitted: boolean
  score: number
}

