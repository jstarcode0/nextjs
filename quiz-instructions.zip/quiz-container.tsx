"use client"

import { useState, useCallback } from "react"
import { RegistrationDialog } from "./components/registration-dialog"
import QuizInstructions from "./quiz-instructions"
import QuizSection from "./quiz-layout"
import { useFullscreen } from "./hooks/use-fullscreen"

interface UserData {
  username: string;
  mobile: string;
  category: string;
  subCategory: string;
}

type QuizState = 'registration' | 'instructions' | 'quiz';

export default function QuizContainer() {
  const [quizState, setQuizState] = useState<QuizState>('registration')
  const [userData, setUserData] = useState<UserData | null>(null)
  const { toggleFullscreen, exitAttempts } = useFullscreen()

  const handleRegistrationComplete = (data: UserData) => {
    setUserData(data)
    setQuizState('instructions')
  }

  const handleStartQuiz = useCallback(async () => {
    await toggleFullscreen()
    setQuizState('quiz')
  }, [toggleFullscreen])

  // If too many exit attempts, auto-submit quiz
  if (exitAttempts >= 2) {
    return <div className="p-4">Quiz has been automatically submitted due to multiple fullscreen exit attempts.</div>
  }

  if (quizState === 'registration') {
    return <RegistrationDialog onSubmit={handleRegistrationComplete} />
  }

  if (quizState === 'instructions') {
    return (
      <QuizInstructions 
        onStart={handleStartQuiz}
        category={userData?.category || ''}
        subCategory={userData?.subCategory || ''}
      />
    )
  }

  return <QuizSection userData={userData} />
}

