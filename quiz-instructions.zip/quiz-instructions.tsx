"use client"

import { useState } from "react"
import { Clock, Flag, X } from 'lucide-react'
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"

interface QuizInstructionsProps {
  onStart: () => void;
  category: string;
  subCategory: string;
}

export default function QuizInstructions({ 
  onStart, 
  category,
  subCategory
}: QuizInstructionsProps) {
  const [accepted, setAccepted] = useState(false)

  const getCategoryLabel = () => {
    const labels: Record<string, string> = {
      'ssc': 'SSC',
      'rsmssb': 'RSMSSB',
      'reet': 'REET'
    }
    return labels[category] || category
  }

  const getSubCategoryLabel = () => {
    const labels: Record<string, string> = {
      'cgl': 'CGL',
      'chsl': 'CHSL',
      'mts': 'MTS',
      'patwari': 'Patwari',
      'police-constable': 'Police Constable',
      'level1': 'Level 1',
      'level2': 'Level 2'
    }
    return labels[subCategory] || subCategory
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <Card className="mx-auto max-w-5xl">
        <CardHeader className="flex flex-row items-center justify-between border-b p-4">
          <div>
            <h1 className="text-xl font-semibold">Quiz Instructions</h1>
            <p className="text-sm text-gray-500 mt-1">
              {getCategoryLabel()} - {getSubCategoryLabel()}
            </p>
          </div>
          <Button variant="ghost" size="icon">
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid gap-8 md:grid-cols-[1fr,300px]">
            <div className="space-y-4">
              <div className="space-y-2">
                {[
                  "This is a timed test, the running time is displayed on top left corner of the screen.",
                  "Sidebar has question panel and you can move to any question by clicking on the respective question number.",
                  "Against the question number in top header, there is an option to mark the question for review. You can later view the marked question.",
                  "You can mark or unmark any option you have chosen by tapping on the respective option.",
                  "You can submit the test at any point of time by clicking the Submit button on bottom of the screen.",
                  "When you click on submit button a confirmation pop-up will be displayed and it will display the test statistics.",
                  "The test will open in full screen mode. You should not exit the full screen mode while attempting test.",
                  "If you try to exit full screen mode more than two times by any means, the test will be submitted automatically and you will not be allowed to attempt the test again.",
                ].map((instruction, index) => (
                  <div key={index} className="flex gap-2">
                    <span className="text-green-600">✓</span>
                    <p className="text-sm text-gray-600">{instruction}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="flex justify-between items-center gap-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Flag className="h-4 w-4" />
                      <span>0 Questions</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Marks</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      <span>05:30:00 Hours</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="text-sm text-gray-600">
                      The following structure of question panel and labels will be there for easy navigations.
                    </p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-8 rounded bg-gray-200 text-center text-sm leading-6">13</span>
                        <span className="text-sm">Not Visited</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-8 rounded bg-green-600 text-center text-white text-sm leading-6">39</span>
                        <span className="text-sm">Answered</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-8 rounded bg-purple-600 text-center text-white text-sm leading-6">13</span>
                        <span className="text-sm">Marked for review</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-8 rounded bg-gray-500 text-center text-white text-sm leading-6">13</span>
                        <span className="text-sm">Visited</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-8 rounded bg-red-600 text-center text-white text-sm leading-6">12</span>
                        <span className="text-sm">Answered but marked for review</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-6 space-y-6">
            <div className="flex items-start gap-2">
              <Checkbox 
                id="terms" 
                checked={accepted}
                onCheckedChange={(checked) => setAccepted(checked)}
                className="mt-1"
              />
              <label htmlFor="terms" className="text-sm text-gray-600">
                I have carefully read and comprehended the instructions provided. I acknowledge that any failure to adhere to
                these instructions may result in disqualification from this test and/or disciplinary action, including
                potential exclusion from future assessments.
              </label>
            </div>

            <div className="flex justify-center">
              <Button 
                size="lg"
                onClick={onStart}
                disabled={!accepted}
              >
                Start Quiz
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

