"use client"

import { useState, useEffect } from "react"
import { Flag, ChevronLeft, ChevronRight, HelpCircle } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { questions } from "./data/questions"
import dynamic from 'next/dynamic'
import 'katex/dist/katex.min.css'

const Latex = dynamic(() => import('react-latex-next'), {
  ssr: false,
  loading: () => <div className="animate-pulse bg-gray-200 h-6 rounded w-full" />
})

interface UserData {
  username: string;
  mobile: string;
  category: string;
  subCategory: string;
}

interface QuizSectionProps {
  userData: UserData | null;
}

export default function QuizSection({ userData }: QuizSectionProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({})
  const [markedQuestions, setMarkedQuestions] = useState<number[]>([])
  const [timeLeft, setTimeLeft] = useState(90 * 60) // 1.5 hours in seconds
  const [showSubmitDialog, setShowSubmitDialog] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [score, setScore] = useState(0)

  const currentQuestions = userData ? questions[userData.subCategory as keyof typeof questions] || [] : []
  const isLastQuestion = currentQuestion === currentQuestions.length - 1

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          handleSubmitQuiz()
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`
  }

  const handleSubmitQuiz = () => {
    const calculatedScore = Object.entries(selectedAnswers).reduce((acc, [questionIndex, answerIndex]) => {
      return acc + (currentQuestions[parseInt(questionIndex)].correct === answerIndex ? 1 : 0)
    }, 0)
    setScore(calculatedScore)
    setIsSubmitted(true)
    setShowSubmitDialog(false)
  }

  const toggleMarkQuestion = (questionId: number) => {
    setMarkedQuestions((prev) =>
      prev.includes(questionId) ? prev.filter((id) => id !== questionId) : [...prev, questionId]
    )
  }

  // Calculate statistics
  const stats = {
    total: currentQuestions.length,
    attempted: Object.keys(selectedAnswers).length,
    marked: markedQuestions.filter(q => !selectedAnswers[q-1]).length,
    markedAndAnswered: markedQuestions.filter(q => selectedAnswers[q-1] !== undefined).length,
    notVisited: Math.max(0, currentQuestions.length - Object.keys(selectedAnswers).length - markedQuestions.filter(q => !selectedAnswers[q-1]).length)
  }

  if (!userData || currentQuestions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="p-6">
          <p className="text-center text-gray-500">No questions available for this category.</p>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            <div className="text-lg font-semibold">{formatTime(timeLeft)}</div>
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="icon">
                    <HelpCircle className="h-5 w-5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-4">
                  <h3 className="font-semibold mb-4">Question Navigation</h3>
                  <div className="grid grid-cols-5 gap-2">
                    {currentQuestions.map((_, index) => {
                      const isAnswered = selectedAnswers[index] !== undefined
                      const isMarked = markedQuestions.includes(index + 1)
                      const isCurrent = currentQuestion === index

                      let buttonClass = "h-8 w-8 text-sm font-medium rounded"
                      if (isCurrent) {
                        buttonClass += " bg-gray-500 text-white"
                      } else if (isAnswered && isMarked) {
                        buttonClass += " bg-red-600 text-white"
                      } else if (isMarked && !isAnswered) {
                        buttonClass += " bg-purple-600 text-white"
                      } else if (isAnswered) {
                        buttonClass += " bg-green-600 text-white"
                      } else {
                        buttonClass += " bg-gray-200"
                      }

                      return (
                        <button
                          key={index}
                          className={buttonClass}
                          onClick={() => setCurrentQuestion(index)}
                        >
                          {index + 1}
                        </button>
                      )
                    })}
                  </div>
                </PopoverContent>
              </Popover>
              <Button variant="secondary" className="pointer-events-none">
                {userData?.username || "Guest"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-1 md:grid-cols-[1fr_300px] gap-6">
        {/* Main Question Area */}
        <div className="space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Question {currentQuestion + 1}</h2>
              {!isSubmitted && (
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => toggleMarkQuestion(currentQuestions[currentQuestion].id)}
                >
                  <Flag className={`h-4 w-4 ${
                    markedQuestions.includes(currentQuestions[currentQuestion].id) ? "fill-purple-600" : ""
                  }`} />
                </Button>
              )}
            </div>

            <div className="space-y-4">
              <div className="text-gray-700">
                <Latex>{currentQuestions[currentQuestion].question}</Latex>
              </div>

              <RadioGroup
                value={selectedAnswers[currentQuestion]?.toString() || ""}
                onValueChange={(value) =>
                  setSelectedAnswers((prev) => ({ ...prev, [currentQuestion]: parseInt(value) }))
                }
              >
                {currentQuestions[currentQuestion].options.map((option, index) => {
                  const isSelected = selectedAnswers[currentQuestion]?.toString() === index.toString()
                  const isCorrect = isSubmitted && currentQuestions[currentQuestion].correct === index
                  const isWrong = isSubmitted && isSelected && !isCorrect

                  return (
                    <div 
                      key={index} 
                      className={`flex items-center space-x-2 p-4 rounded-lg border transition-colors
                        ${isSubmitted 
                          ? isCorrect 
                            ? "bg-green-50 border-green-200" 
                            : isWrong 
                              ? "bg-red-50 border-red-200"
                              : "border-gray-200" 
                          : isSelected
                            ? "bg-gray-100 border-gray-300"
                            : "border-gray-200 hover:bg-gray-50"
                        }`}
                    >
                      <RadioGroupItem 
                        value={index.toString()} 
                        id={`option-${currentQuestion}-${index}`}
                        disabled={isSubmitted}
                      />
                      <Label 
                        htmlFor={`option-${currentQuestion}-${index}`} 
                        className={`flex-1 cursor-pointer ${
                          isSubmitted && isCorrect ? "text-green-700 font-medium" : ""
                        }`}
                      >
                        <Latex>{option}</Latex>
                      </Label>
                    </div>
                  )
                })}
              </RadioGroup>
            </div>

            <div className="flex justify-between mt-6">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
                disabled={currentQuestion === 0}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>
              {!isLastQuestion ? (
                <Button
                  onClick={() => setCurrentQuestion((prev) => Math.min(currentQuestions.length - 1, prev + 1))}
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Button
                  variant="destructive"
                  onClick={() => setShowSubmitDialog(true)}
                >
                  Submit Quiz
                </Button>
              )}
            </div>

            {isSubmitted && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <p className="text-lg font-medium">
                  Final Score: {score} out of {currentQuestions.length} ({Math.round((score/currentQuestions.length) * 100)}%)
                </p>
              </div>
            )}
          </Card>
        </div>

        {/* Question Navigation Panel */}
        <div className="space-y-4">
          <Card className="p-4">
            <h3 className="font-semibold mb-4">Question Status</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-6 w-8 rounded bg-gray-200 flex items-center justify-center text-xs font-medium">
                    {stats.notVisited}
                  </span>
                  <span className="text-sm">Not Visited</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-6 w-8 rounded bg-green-600 text-white flex items-center justify-center text-xs font-medium">
                    {stats.attempted}
                  </span>
                  <span className="text-sm">Answered</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-6 w-8 rounded bg-purple-600 text-white flex items-center justify-center text-xs font-medium">
                    {stats.marked}
                  </span>
                  <span className="text-sm">Marked for review</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-6 w-8 rounded bg-red-600 text-white flex items-center justify-center text-xs font-medium">
                    {stats.markedAndAnswered}
                  </span>
                  <span className="text-sm">Answered & marked</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-destructive">Confirm Test Submission</DialogTitle>
            <DialogDescription>
              Please review your progress before submitting:
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid gap-2 text-sm">
              <div className="flex justify-between">
                <span>Total Questions:</span>
                <span className="font-medium">{stats.total}</span>
              </div>
              <div className="flex justify-between">
                <span>Attempted:</span>
                <span className="font-medium text-green-600">{stats.attempted}</span>
              </div>
              <div className="flex justify-between">
                <span>Not Visited:</span>
                <span className="font-medium text-gray-500">{stats.notVisited}</span>
              </div>
              <div className="flex justify-between">
                <span>Marked for Review:</span>
                <span className="font-medium text-purple-600">{stats.marked}</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Are you sure you want to submit? This action cannot be undone.
            </p>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
              Return to Quiz
            </Button>
            <Button variant="destructive" onClick={handleSubmitQuiz}>
              Confirm Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

