export const questions = {
  // SSC Questions
  'cgl': [
    {
      id: 1,
      question: "If 3x + 4y = 10 and 2x - y = 2, find the value of x.",
      options: ["2", "3", "4", "1"],
      correct: 0,
      isMath: true
    },
    {
      id: 2,
      question: "Which among these is the largest democracy in the world?",
      options: ["USA", "India", "Russia", "Brazil"],
      correct: 1
    }
  ],
  'chsl': [
    {
      id: 1,
      question: "Solve: \\[ \\sqrt{144} + \\sqrt{169} = ? \\]",
      options: ["25", "12", "24", "13"],
      correct: 0,
      isMath: true
    }
  ],
  
  // RSMSSB Questions
  'patwari': [
    {
      id: 1,
      question: "राजस्थान का राजकीय पशु क्या है?",
      options: ["चिंकारा", "ऊंट", "बाघ", "सिंह"],
      correct: 0
    },
    {
      id: 2,
      question: "Find the area of a circle: \\[ A = \\pi r^2, \\text{ where } r = 7 \\]",
      options: ["49π", "14π", "28π", "21π"],
      correct: 0,
      isMath: true
    }
  ],
  'police-constable': [
    {
      id: 1,
      question: "भारत में सबसे लंबी सड़क कौन सी है?",
      options: [
        "NH 44 (Grand Trunk Road)",
        "NH 27",
        "NH 48",
        "NH 52"
      ],
      correct: 0
    }
  ],

  // REET Questions
  'level1': [
    {
      id: 1,
      question: "Evaluate: \\[ \\lim_{x \\to 0} \\frac{\\sin x}{x} \\]",
      options: [
        "0",
        "1",
        "\\infty",
        "\\text{Does not exist}"
      ],
      correct: 1,
      isMath: true
    },
    {
      id: 2,
      question: "बाल विकास एवं शिक्षाशास्त्र के अनुसार, बच्चों के सीखने की प्रक्रिया में सबसे महत्वपूर्ण कारक क्या है?",
      options: [
        "अनुभव द्वारा सीखना",
        "रटकर सीखना",
        "दबाव में सीखना",
        "केवल किताबी ज्ञान"
      ],
      correct: 0
    }
  ],
  'level2': [
    {
      id: 1,
      question: "Solve the quadratic equation: \\[ x^2 - 7x + 12 = 0 \\]",
      options: [
        "x = 3, 4",
        "x = -3, -4",
        "x = 4, 3",
        "x = -4, 3"
      ],
      correct: 0,
      isMath: true
    }
  ]
}

