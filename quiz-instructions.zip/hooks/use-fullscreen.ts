"use client"

import { useState, useEffect, useCallback } from "react"

export function useFullscreen() {
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [exitAttempts, setExitAttempts] = useState(0)

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen()
        setIsFullscreen(true)
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen()
          setIsFullscreen(false)
        }
      }
    } catch (err) {
      console.error('Error attempting to toggle full-screen:', err)
    }
  }, [])

  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement && isFullscreen) {
        setExitAttempts(prev => prev + 1)
      }
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange)
  }, [isFullscreen])

  return { isFullscreen, toggleFullscreen, exitAttempts }
}

