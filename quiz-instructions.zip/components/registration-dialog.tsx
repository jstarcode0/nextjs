"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"

interface UserData {
  username: string;
  mobile: string;
  category: string;
  subCategory: string;
}

interface Props {
  onSubmit: (data: UserData) => void;
}

const categories = {
  'ssc': [
    { value: 'cgl', label: 'CGL' },
    { value: 'chsl', label: 'CHSL' },
    { value: 'mts', label: 'MTS' },
    { value: 'cpo', label: 'CPO' }
  ],
  'rsmssb': [
    { value: 'patwari', label: 'Patwari' },
    { value: 'police-constable', label: 'Police Constable' },
    { value: 'clerk', label: 'Clerk Grade II' },
    { value: 'lab-assistant', label: 'Lab Assistant' }
  ],
  'reet': [
    { value: 'level1', label: 'Level 1' },
    { value: 'level2', label: 'Level 2' }
  ]
} as const;

export function RegistrationDialog({ onSubmit }: Props) {
  const [formData, setFormData] = useState<UserData>({
    username: '',
    mobile: '',
    category: '',
    subCategory: ''
  })
  const [error, setError] = useState('')

  const handleSubmit = () => {
    if (!formData.username || !formData.mobile || !formData.category || !formData.subCategory) {
      setError('Please fill all fields')
      return
    }
    if (formData.mobile.length !== 10 || !/^\d+$/.test(formData.mobile)) {
      setError('Please enter a valid 10-digit mobile number')
      return
    }
    onSubmit(formData)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-6">
        <div className="space-y-6">
          <div className="text-center">
            <h1 className="text-2xl font-bold">Quiz Registration</h1>
            <p className="text-gray-500 mt-2">Please complete registration to start the quiz</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Full Name</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => {
                  setFormData(prev => ({ ...prev, username: e.target.value }))
                  setError('')
                }}
                placeholder="Enter your full name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="mobile">Mobile Number</Label>
              <Input
                id="mobile"
                value={formData.mobile}
                onChange={(e) => {
                  setFormData(prev => ({ ...prev, mobile: e.target.value }))
                  setError('')
                }}
                placeholder="Enter your mobile number"
                maxLength={10}
              />
            </div>

            <div className="space-y-2">
              <Label>Select Exam Category</Label>
              <Select 
                value={formData.category}
                onValueChange={(value) => {
                  setFormData(prev => ({ ...prev, category: value, subCategory: '' }))
                  setError('')
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select exam category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ssc">SSC</SelectItem>
                  <SelectItem value="rsmssb">RSMSSB</SelectItem>
                  <SelectItem value="reet">REET</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.category && (
              <div className="space-y-2">
                <Label>Select Sub-Category</Label>
                <Select 
                  value={formData.subCategory}
                  onValueChange={(value) => {
                    setFormData(prev => ({ ...prev, subCategory: value }))
                    setError('')
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select sub-category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories[formData.category as keyof typeof categories].map(sub => (
                      <SelectItem key={sub.value} value={sub.value}>
                        {sub.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {error && (
              <p className="text-sm text-red-500">{error}</p>
            )}

            <Button className="w-full" onClick={handleSubmit}>
              Continue to Instructions
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

