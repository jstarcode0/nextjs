"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useState } from "react"

interface QuizInstructionsProps {
  onStart: () => void;
}

export function QuizInstructions({ onStart }: QuizInstructionsProps) {
  const [accepted, setAccepted] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <Card className="mx-auto max-w-5xl">
        <div className="p-6 space-y-6">
          <div className="space-y-4">
            <h1 className="text-2xl font-bold text-center">Quiz Instructions</h1>
            <p className="text-gray-500 text-center">Please read the following instructions carefully</p>
          </div>

          <div className="space-y-4">
            {[
              "This is a timed test of 1.5 hours duration.",
              "Each question has only one correct answer.",
              "You can mark questions for review and return to them later.",
              "Questions can be attempted in any order.",
              "You can change your answer before final submission.",
              "The test will auto-submit when the time expires.",
              "Leaving full screen mode twice will auto-submit your test.",
              "Your final score will be displayed after submission.",
              "Mathematical expressions are rendered properly for math questions.",
              "Hindi text is supported for language questions."
            ].map((instruction, index) => (
              <div key={index} className="flex gap-2">
                <span className="text-green-600">✓</span>
                <p className="text-sm text-gray-600">{instruction}</p>
              </div>
            ))}
          </div>

          <div className="space-y-6">
            <div className="flex items-start gap-2">
              <Checkbox 
                id="accept"
                checked={accepted}
                onCheckedChange={(checked) => setAccepted(checked as boolean)}
                className="mt-1"
              />
              <label htmlFor="accept" className="text-sm text-gray-600">
                I have carefully read and understood all the instructions. I agree to follow them
                and acknowledge that any violation may result in disqualification.
              </label>
            </div>

            <Button 
              className="w-full"
              disabled={!accepted}
              onClick={onStart}
            >
              Start Quiz
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

